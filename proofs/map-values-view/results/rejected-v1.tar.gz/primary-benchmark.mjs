import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawnSync, execFileSync } from 'node:child_process';
import { mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { resolve, dirname, join } from 'node:path';
import { pathToFileURL } from 'node:url';
import os from 'node:os';

// One public full scan per operation; construction and correctness checks are
// untimed. Each process loads exactly one bundle and executes exactly one case.
export const CASES = [
  ...[0, 1, 32, 4096, 65536].map(size => ({ type: 'number', size, operation: 'values' })),
  ...[32, 4096, 65536].map(size => ({ type: 'boolean', size, operation: 'values' })),
  { type: 'string', size: 4096, operation: 'values' },
  { type: 'object', size: 4096, operation: 'values' },
  { type: 'number', size: 4096, operation: 'get' },
].map(row => ({ ...row, name: `${row.type}/${row.size}/${row.operation}`,
  role: ['number', 'boolean'].includes(row.type) && row.operation === 'values' ? 'target' : 'control' }));
export const CONFIG = Object.freeze({ rounds: 6, aaRounds: 4, samples: 15, warmupMs: 250,
  minimumWarmupBatches: 8, targetBatchMs: 12, aaCases: ['number/4096/values', 'boolean/4096/values', 'number/4096/get'] });
export const median = values => {
  assert.ok(values.length);
  const sorted = [...values].sort((a, b) => a - b), mid = sorted.length >>> 1;
  return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
};
const sha256 = value => createHash('sha256').update(value).digest('hex');

function interval(ratios) {
  // Independent units are fresh process pairs, never the batches within them.
  const logs = ratios.map(Math.log), mean = logs.reduce((s, n) => s + n, 0) / logs.length;
  const variance = logs.reduce((s, n) => s + (n - mean) ** 2, 0) / (logs.length - 1);
  const t = { 4: 3.182446305284, 6: 2.570581835636 }[logs.length];
  assert.ok(t, 'The fixed study uses four A/A or six A/B pairs');
  const radius = t * Math.sqrt(variance / logs.length);
  return { estimate: Math.exp(mean), lower95: Math.exp(mean - radius), upper95: Math.exp(mean + radius) };
}

function summarize(record) {
  const result = [];
  for (const runtime of ['node', 'bun']) for (const mode of ['ab', 'aa']) for (const workload of CASES) {
    const rows = record.pairs.filter(row => row.runtime === runtime && row.mode === mode && row.name === workload.name);
    const wanted = mode === 'ab' ? CONFIG.rounds : CONFIG.aaRounds;
    if (rows.length !== wanted) continue;
    const ratios = rows.map(row => row.right.medianMsPerScan / row.left.medianMsPerScan);
    result.push({ runtime, mode, ...workload, pairs: rows.length,
      baselineMs: median(rows.map(row => row.left.medianMsPerScan)),
      candidateMs: median(rows.map(row => row.right.medianMsPerScan)),
      latencyRatio: interval(ratios), pairedRatios: ratios,
      minMeasuredBatchMs: Math.min(...rows.flatMap(row => [...row.left.samplesMs, ...row.right.samplesMs])),
    });
  }
  return result;
}

async function child() {
  const [entry, name, repeatText] = process.argv.slice(3), workload = CASES.find(row => row.name === name);
  assert.ok(workload, `Unknown case ${name}`);
  const S = await import(pathToFileURL(resolve(entry)).href);
  const { type, size, operation } = workload;
  const value = i => type === 'number' ? i + 0.25 : type === 'boolean' ? i % 3 === 0
    : type === 'string' ? `value-${i}` : { n: i, tags: [i & 7, 5] };
  const entries = Array.from({ length: size }, (_, i) => [`key-${i}`, value(i)]), model = new Map(entries);
  const map = new S.SharedMap(type).setMany(entries), keys = [...model.keys()];
  assert.deepEqual([...map.values()], [...map.keys()].map(key => model.get(key)), 'Public value order and content');
  const score = type === 'number' ? value => value : type === 'boolean' ? value => value ? 1 : 0
    : type === 'string' ? value => value.length : value => value.n + value.tags[0] + value.tags[1];
  const expectedSum = entries.reduce((sum, [, value]) => sum + score(value), 0);
  const source = S.getWorkerData({ map }, { copy: false }).arenas[0];
  const bytesBefore = sha256(new Uint8Array(source.memory.buffer, 65536, source.used - 65536));
  function scan(repeat) {
    let sum = 0, count = 0;
    if (operation === 'values') {
      for (let r = 0; r < repeat; r++) for (const value of map.values()) { sum += score(value); count++; }
    } else {
      for (let r = 0; r < repeat; r++) for (const key of keys) { sum += score(map.get(key)); count++; }
    }
    return { sum, count };
  }
  function measure(repeat) {
    const start = performance.now(), actual = scan(repeat), elapsed = performance.now() - start;
    assert.equal(actual.sum, expectedSum * repeat); assert.equal(actual.count, size * repeat);
    return elapsed;
  }
  let repeat = Number(repeatText) || Math.max(1, Math.ceil(32768 / Math.max(size, 1)));
  assert.ok(Number.isSafeInteger(repeat) && repeat > 0 && repeat <= 10000000);
  const warmupMs = []; let warmTime = 0;
  while (warmTime < CONFIG.warmupMs || warmupMs.length < CONFIG.minimumWarmupBatches) {
    const elapsed = measure(repeat); warmupMs.push(elapsed); warmTime += elapsed;
  }
  const calibration = [];
  if (!Number(repeatText)) {
    for (let step = 0; step < 12; step++) {
      const samples = Array.from({ length: 3 }, () => measure(repeat));
      calibration.push({ repeat, samplesMs: samples });
      const time = median(samples);
      if (time >= CONFIG.targetBatchMs * 1.25) break;
      repeat = Math.ceil(repeat * Math.min(8, Math.max(1.1, CONFIG.targetBatchMs * 1.5 / Math.max(time, 0.001))));
      assert.ok(repeat <= 10000000, 'Calibration repeat cap');
    }
    assert.ok(median(calibration.at(-1).samplesMs) >= CONFIG.targetBatchMs * 1.25, 'Calibration completed');
  }
  const samplesMs = Number(repeatText) ? Array.from({ length: CONFIG.samples }, () => measure(repeat)) : [];
  const after = S.getWorkerData({ map }, { copy: false }).arenas[0];
  assert.equal(after.used, source.used, 'No shared allocation during reads');
  assert.equal(sha256(new Uint8Array(after.memory.buffer, 65536, after.used - 65536)), bytesBefore, 'Immutable bytes');
  const result = { runtime: process.versions.bun ? 'bun' : 'node', versions: process.versions,
    arch: process.arch, name, repeat, expectedSum, expectedCount: size, snapshotBytes: source.used - 65536,
    snapshotSha256: bytesBefore, zeroSharedAllocation: true, warmupMs, calibration, samplesMs,
    medianMsPerScan: samplesMs.length ? median(samplesMs) / repeat : null };
  process.stdout.write(JSON.stringify(result));
}

function manifest(root) {
  const files = execFileSync('git', ['ls-files', '-z'], { cwd: root, encoding: 'utf8' }).split('\0')
    .filter(path => !path.includes('/') && path.endsWith('.ts') && !path.endsWith('.test.ts'));
  const bundles = readdirSync(join(root, 'dist')).filter(path => path.endsWith('.js')).sort();
  return { commit: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim(),
    source: Object.fromEntries(files.map(path => [path, sha256(readFileSync(join(root, path)))])),
    bundles: Object.fromEntries(bundles.map(path => [path, sha256(readFileSync(join(root, 'dist', path)))])),
    wasm: sha256(readFileSync(join(root, 'persistent-core.wasm'))) };
}

async function run() {
  const [baselineArg, candidateArg, bunArg, outputArg] = process.argv.slice(2);
  assert.ok(baselineArg && candidateArg && bunArg && outputArg,
    'Usage: node benchmark.mjs BASELINE_ROOT CANDIDATE_ROOT BUN_EXECUTABLE OUTPUT.json');
  const roots = { baseline: resolve(baselineArg), candidate: resolve(candidateArg) }, output = resolve(outputArg);
  mkdirSync(dirname(output), { recursive: true });
  const record = { schema: 1, createdAt: new Date().toISOString(), status: 'running', method: CONFIG, cases: CASES,
    hardware: { platform: process.platform, arch: process.arch, cpu: os.cpus()[0].model, logicalCpus: os.cpus().length },
    source: { baseline: manifest(roots.baseline), candidate: manifest(roots.candidate), harness: sha256(readFileSync(import.meta.filename)) },
    pilots: [], pairs: [], summary: [] };
  assert.equal(record.source.baseline.wasm, record.source.candidate.wasm, 'Wasm must stay identical');
  const changed = Object.keys(record.source.baseline.source).filter(path => record.source.baseline.source[path] !== record.source.candidate.source[path]);
  assert.deepEqual(changed, ['shared-map.ts'], 'Only the intended production source changed');
  const save = () => { record.summary = summarize(record); writeFileSync(output, JSON.stringify(record, null, 2) + '\n'); };
  function execute(runtime, executable, variant, name, repeat) {
    const args = [import.meta.filename, '--child', join(roots[variant], 'dist/shared.js'), name, String(repeat)];
    const start = Date.now(), result = spawnSync(executable, args, { encoding: 'utf8', timeout: 120000, maxBuffer: 8 * 1024 * 1024 });
    if (result.status !== 0) {
      record.failure = { runtime, variant, name, repeat, status: result.status, stdout: result.stdout, stderr: result.stderr, error: String(result.error ?? '') };
      record.status = 'failed'; save(); throw new Error(`Child failed: ${runtime}/${name}/${variant}: ${result.stderr}`);
    }
    const value = JSON.parse(result.stdout);
    assert.equal(value.runtime, runtime); assert.equal(value.arch, process.arch); assert.equal(value.name, name);
    assert.equal(value.zeroSharedAllocation, true);
    return { ...value, durationMs: Date.now() - start };
  }
  save();
  for (const [runtime, executable] of [['node', process.execPath], ['bun', resolve(bunArg)]]) {
    const repeats = new Map();
    for (const workload of CASES) {
      const baseline = execute(runtime, executable, 'baseline', workload.name, 0), candidate = execute(runtime, executable, 'candidate', workload.name, 0);
      assert.equal(baseline.expectedSum, candidate.expectedSum); assert.equal(baseline.snapshotSha256, candidate.snapshotSha256);
      const repeat = Math.max(baseline.repeat, candidate.repeat); repeats.set(workload.name, repeat);
      record.pilots.push({ runtime, name: workload.name, repeat, baseline, candidate }); save();
    }
    for (const mode of ['ab', 'aa']) {
      const cases = mode === 'ab' ? CASES : CASES.filter(row => CONFIG.aaCases.includes(row.name));
      for (let round = 0; round < (mode === 'ab' ? CONFIG.rounds : CONFIG.aaRounds); round++) {
        // Rotate case order and reverse each process pair on alternate rounds.
        const ordered = [...cases.slice(round % cases.length), ...cases.slice(0, round % cases.length)];
        for (const workload of ordered) {
          const order = round % 2 ? ['right', 'left'] : ['left', 'right'], pair = { runtime, mode, round, name: workload.name, order };
          for (const role of order) pair[role] = execute(runtime, executable,
            mode === 'ab' && role === 'right' ? 'candidate' : 'baseline', workload.name, repeats.get(workload.name));
          assert.equal(pair.left.expectedSum, pair.right.expectedSum); assert.equal(pair.left.snapshotSha256, pair.right.snapshotSha256);
          record.pairs.push(pair); save();
        }
        console.log(`${runtime} ${mode} round ${round + 1} complete`);
      }
    }
  }
  assert.deepEqual(manifest(roots.baseline), record.source.baseline, 'Baseline changed during measurement');
  assert.deepEqual(manifest(roots.candidate), record.source.candidate, 'Candidate changed during measurement');
  record.status = 'complete'; record.completedAt = new Date().toISOString(); save();
  for (const row of record.summary) console.log(JSON.stringify({ runtime: row.runtime, mode: row.mode, name: row.name,
    baselineMs: row.baselineMs, candidateMs: row.candidateMs, ...row.latencyRatio }));
}

if (process.argv[2] === '--child') await child();
else if (process.argv[1] && resolve(process.argv[1]) === import.meta.filename) await run();
