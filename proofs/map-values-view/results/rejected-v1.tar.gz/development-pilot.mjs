import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { spawnSync } from 'node:child_process';
import os from 'node:os';
const median = a => [...a].sort((x,y)=>x-y)[a.length>>>1];
if (process.argv[2] === 'child') {
  const [module, type, sizeText] = process.argv.slice(3), size=+sizeText;
  const S=await import(pathToFileURL(module).href);
  const entries=Array.from({length:size},(_,i)=>[`key-${i}`,type==='number'?i:i%3===0]);
  const map=new S.SharedMap(type).setMany(entries), expected=entries.reduce((s,[,v])=>s+v,0);
  const repeat=Math.max(2,Math.ceil(250000/Math.max(size,1)));
  function scan() { let sum=0; for(let r=0;r<repeat;r++) for(const v of map.values()) sum+=v; return sum; }
  const warm=[]; let total=0;
  while(total<180) { const start=performance.now(); assert.equal(scan(),expected*repeat); const time=performance.now()-start; warm.push(time); total+=time; }
  const samples=[]; for(let i=0;i<11;i++) { const start=performance.now(); const sum=scan(); const time=performance.now()-start; assert.equal(sum,expected*repeat); samples.push(time/repeat); }
  process.stdout.write(JSON.stringify({runtime:process.versions,repeat,warm,samples,median:median(samples),expected}));
} else {
  const roots={baseline:'/workspace/scratch/83f1d4baba1f/zerocopy',candidate:'/workspace/scratch/83f1d4baba1f/zerocopy-map'};
  const all=[];
  for(const runtime of [process.execPath,'/workspace/scratch/83f1d4baba1f/tools/bun']) for(const size of [4096,65536]) for(const type of ['number','boolean']) {
    const data=[];
    for(const variant of ['baseline','candidate','candidate','baseline']) {
      const child=spawnSync(runtime,[import.meta.filename,'child',roots[variant]+'/dist/shared.js',type,String(size)],{encoding:'utf8'});
      assert.equal(child.status,0,child.stderr); data.push({variant,...JSON.parse(child.stdout)});
    }
    const before=median(data.filter(x=>x.variant==='baseline').map(x=>x.median)), after=median(data.filter(x=>x.variant==='candidate').map(x=>x.median));
    const row={runtime,size,type,before,after,speedup:before/after,data}; all.push(row); console.log(JSON.stringify({runtime:runtime.endsWith('bun')?'bun':'node',size,type,before,after,speedup:before/after}));
    writeFileSync('/workspace/scratch/83f1d4baba1f/results/map-values-pilot.json',JSON.stringify({cpu:os.cpus()[0].model,all},null,2));
  }
}
