#!/usr/bin/env python3
"""Bundle both validation attempts and their exact logs without discarding failures."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    first_path = ROOT / "attempt-01/combined-validation.json"
    second_path = ROOT / "attempt-02/combined-validation.json"
    first, second = json.loads(first_path.read_text()), json.loads(second_path.read_text())
    assert first["status"] == "failed" and first["failedCommand"] == "full-vitest-bun"
    assert second["status"] == "passed" and second["phase"] == "complete"
    assert second["totals"]["full-vitest-bun"] == {"filesPassed": 59, "testsPassed": 1178}
    assert second["totals"]["focused-vitest-node"] == {"filesPassed": 2, "testsPassed": 31}
    destination = ROOT / "deliverable"
    assert not destination.exists(), "Do not overwrite delivered evidence"
    destination.mkdir()
    for name in ["attempt-01", "attempt-02"]:
        shutil.copytree(ROOT / name, destination / name)
    for name in ["inputs.json", "run.py", "recover-core.py", "finalize.py",
                 "package-evidence.py", "reproduce-fixture-leak.mjs"]:
        shutil.copy2(ROOT / name, destination / name)
    log = destination / "combined-validation.log"
    log.write_text(
        "Combined correctness only. No combined performance measurements.\n"
        "The default full suite FAILED; the later isolated full suite PASSED. All original evidence follows.\n\n"
        "===== ATTEMPT 1: default configuration, failure retained =====\n"
        + (ROOT / "attempt-01/combined-validation.log").read_text()
        + "\n===== BASELINE AND COMBINED FIXTURE-LEAK REPRODUCTION =====\n"
        + (ROOT / "attempt-01/baseline-fixture-leak.json").read_text()
        + "\n===== ATTEMPT 2: isolated suite and remaining/final gates =====\n"
        + (ROOT / "attempt-02/combined-validation.log").read_text()
    )
    commands = first["commands"] + second["commands"]
    summary = {
        "schema": "zerocopy-combined-correctness/1", "status": "passed-with-documented-retry",
        "performanceMeasurements": False, "baseline": second["baseline"],
        "runtime": second["runtime"], "candidates": second["candidates"],
        "sourceSha256": second["finalSourceSha256After"],
        "builtArtifactSha256": second["builtArtifactSha256"],
        "nativeBuildReuse": second["nativeBuildReuse"],
        "defaultSuitePassed": False, "isolatedSuitePassed": True,
        "fullSuite": second["totals"]["full-vitest-bun"],
        "focusedNodeSuite": second["totals"]["focused-vitest-node"],
        "failureAnalysis": {
            "copyAttachment": "The unchanged worker-records.test.ts fake-Arena graph remains in the default SharedMap arena with Vitest isolate:false. A later SharedSet copy attachment visits a fake object without copy(). The same failure and reset behavior were reproduced on the untouched baseline and combined runtime.",
            "allocationTimeouts": "Existing sorted-map replacement and list-tail replacement tests exceeded the default 5000 ms limit (5212 and 5399 ms) during the parallel suite. Their timeouts were not separately reproduced on baseline. Both passed in the full isolated run using a 15000 ms timeout.",
            "changes": "CLI --isolate --testTimeout 15000 only; runtime, regression tests, baseline tests and Vitest config were unchanged. Seven previously passed build/typecheck gates were reused with exact hashes and logs.",
        },
        "attempts": [
            {"path": "attempt-01/combined-validation.json", "sha256": digest(first_path), "status": first["status"]},
            {"path": "attempt-02/combined-validation.json", "sha256": digest(second_path), "status": second["status"]},
        ],
        "commandsExecuted": len(commands),
        "commandExitCodes": {"zero": sum(item["exitCode"] == 0 for item in commands),
                             "nonzero": sum(item["exitCode"] != 0 for item in commands)},
        "allRequestedGatesEventuallyPassed": True,
        "log": {"path": log.name, "sha256": digest(log)},
    }
    readme = f"""# Combined correctness validation\n\nThe final heap-read and primitive-vector-compaction changes work together: **59 files / 1,178 tests passed** under Bun with file isolation; the **31 new regressions passed** under Node. Portable build, declarations, main/Redux/values/geometry/worker typechecks, real Node workers, Chromium workers, late imports, installed-package checks, author documentation checks, and every saved timing-record verifier passed. This directory contains correctness evidence only; it makes no combined speed claim.\n\n## Failed default attempt and exact recovery\n\n**The default full suite did not pass.** Attempt 1 reported 1,175 passed / 3 failed tests. Two existing allocation-failure tests exceeded their 5-second timeout. The third failure (`arena.copy is not a function`) came from the unchanged `worker-records.test.ts` fake dependency graph leaking through the default SharedMap arena into a later SharedSet copy test while `isolate:false` is configured. The included reproduction demonstrates the same clean/failing/reset behavior on the untouched baseline and combined runtime. The two timeout failures were not separately reproduced on baseline.\n\nAttempt 2 used the unchanged tests and runtime with:\n\n```sh\nbun run test --isolate --testTimeout 15000\n```\n\nAll 1,178 tests passed. Runtime files, test files, and Vitest config were not changed to recover. The seven successful build/typecheck commands from attempt 1 were reused; their logs and hashes remain in that attempt. Both complete attempts are retained, including the original failure.\n\n## Inputs and provenance\n\n- Baseline: `{second['baseline']}`.\n- Heap commit: `{second['candidates']['heap']['commit']}`.\n- Compaction commit: `{second['candidates']['compaction']['commit']}`.\n- Node: `{second['runtime']['node']}`; Bun: `{second['runtime']['bun']}`.\n- The shared Arena change is byte-identical in both candidates. Only five runtime files and the two new regression suites were overlaid; the rejected map experiment is absent.\n- Unchanged native sources and build script were compared byte-for-byte before reusing the baseline WASM. All 12 native artifact hashes are recorded.\n- Every build/test/evidence command ran after both final performance studies completed, under `/tmp/zerocopy-perf-20261108.lock`. No combined timing study was run.\n\n## Evidence files\n\n`combined-validation.json` summarizes outcomes and exact source/build hashes. `combined-validation.log` includes both attempts and the baseline reproduction. The attempt directories retain every command's full log, argv, working directory, exit code, timestamps, and hashes. The final attempt also records the final proof-directory inventories and all historical/final timing evidence verification.\n\n`reproduce-fixture-leak.mjs` accepts a source-checkout path:\n\n```sh\nbun reproduce-fixture-leak.mjs /path/to/untouched-baseline\nbun reproduce-fixture-leak.mjs /path/to/combined-checkout\n```\n\nThe Python scripts record the actual local orchestration. Their original absolute checkout paths remain in `inputs.json` and the manifests for provenance; use equivalent local paths when reproducing the recorded commands.\n"""
    (destination / "README.md").write_text(readme)
    summary["artifactSha256"] = {str(path.relative_to(destination)): digest(path)
                                for path in sorted(destination.rglob("*")) if path.is_file()}
    (destination / "combined-validation.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({"directory": str(destination), "files": len(summary["artifactSha256"]) + 1,
                      "commandsExecuted": summary["commandsExecuted"], "exitCodes": summary["commandExitCodes"],
                      "fullSuite": summary["fullSuite"], "focusedNodeSuite": summary["focusedNodeSuite"]}))


if __name__ == "__main__":
    main()
