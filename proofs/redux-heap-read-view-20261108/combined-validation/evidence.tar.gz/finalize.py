#!/usr/bin/env python3
"""Append final author docs/evidence checks to successful combined correctness evidence."""
from __future__ import annotations

import argparse
import fcntl
import json
import os
from pathlib import Path
import subprocess
import time

import run as core


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--attempt", required=True)
    args = parser.parse_args()
    inputs = json.loads(core.INPUTS.read_text())
    evidence = core.ROOT / args.attempt
    manifest_path = evidence / "combined-validation.json"
    log_path = evidence / "combined-validation.log"
    manifest = json.loads(manifest_path.read_text())
    assert manifest["status"] == "passed" and manifest["phase"] == "core"
    assert all(inputs["handoffs"][name]["studiesFinished"]
               and inputs["handoffs"][name]["reportsAndWorkflowFinished"]
               for name in ["heap", "compaction"])
    repository = Path(inputs["combinedDirectory"])
    for candidate in inputs["candidates"].values():
        for name, expected in {**candidate["runtime"], **candidate["testHashes"]}.items():
            assert core.digest(repository / name) == expected
            assert core.digest(Path(candidate["root"]) / name) == expected
        for name, expected in candidate["copiedProofSha256"].items():
            assert core.digest(repository / name) == expected
    current = core.source_hashes(repository)
    for name, expected in manifest["sourceSha256After"].items():
        assert current[name] == expected, f"Previously validated source or proof script changed: {name}"
    additions = [{"name": "combined-final-diff-whitespace",
                  "argv": ["git", "diff", "--check", inputs["baseline"]],
                  "cwd": str(repository)}, *inputs["additionalGates"]]
    assert {step["name"] for step in additions} >= {
        "heap-diff-whitespace", "heap-docs-preserve", "heap-all-evidence",
        "compaction-diff-whitespace", "compaction-docs-preserve", "compaction-all-evidence"}
    env = os.environ.copy()
    env["PATH"] = "/workspace/scratch/d81d52bea579/bin:" + env.get("PATH", "")

    with core.LOCK.open("a+") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        manifest["coreCompletedAt"] = manifest["completedAt"]
        manifest["coreTotals"] = manifest["totals"].copy()
        manifest["coreHandoffs"] = manifest["handoffs"]
        manifest["candidates"] = inputs["candidates"]
        manifest["handoffs"] = inputs["handoffs"]
        manifest["additionalGates"] = inputs["additionalGates"]
        manifest.update({"status": "running", "phase": "author-gates", "finalInputs": inputs,
                         "authorGatesStartedAt": core.now(), "finalizerSha256": core.digest(Path(__file__)),
                         "finalSourceSha256Before": current})
        total = len(manifest["commands"]) + len(additions)

        def save():
            manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")

        save()
        failure = None
        with log_path.open("a") as full_log:
            full_log.write("\nFinal author reports are committed; checking all saved evidence and docs.\n")
            full_log.flush()
            for extra in additions:
                index = len(manifest["commands"]) + 1
                name, argv, directory = extra["name"], extra["argv"], extra["cwd"]
                command_log = evidence / f"{index:02d}-{name}.log"
                assert not command_log.exists()
                start = time.monotonic()
                record = {"index": index, "name": name, "argv": argv, "cwd": directory,
                          "startedAt": core.now()}
                full_log.write(f"\n=== {index}/{total}: {name} ===\n{json.dumps(argv)}\n")
                full_log.flush()
                with command_log.open("w") as destination:
                    process = subprocess.Popen(argv, cwd=directory, env=env, stdout=subprocess.PIPE,
                                               stderr=subprocess.STDOUT, text=True, bufsize=1)
                    assert process.stdout is not None
                    for line in process.stdout:
                        full_log.write(line)
                        destination.write(line)
                        full_log.flush()
                        destination.flush()
                    code = process.wait()
                record.update({"completedAt": core.now(), "durationSeconds": round(time.monotonic() - start, 6),
                               "exitCode": code, "log": command_log.name, "logSha256": core.digest(command_log),
                               "logBytes": command_log.stat().st_size})
                manifest["commands"].append(record)
                save()
                print(json.dumps({"step": index, "total": total, "name": name,
                                  "exitCode": code, "durationSeconds": record["durationSeconds"]}), flush=True)
                if code:
                    failure = name
                    break
        manifest["finalSourceSha256After"] = core.source_hashes(repository)
        assert manifest["finalSourceSha256After"] == current
        for candidate in inputs["candidates"].values():
            for name, expected in candidate["copiedProofSha256"].items():
                assert core.digest(repository / name) == expected
        manifest["completedAt"] = core.now()
        manifest["phase"] = "complete"
        manifest["status"] = "failed" if failure else "passed"
        manifest["failedCommand"] = failure
        manifest["log"] = {"filename": log_path.name, "sha256": core.digest(log_path),
                           "bytes": log_path.stat().st_size}
        manifest["totals"].update({"commandsPlanned": total, "commandsCompleted": len(manifest["commands"]),
                                   "commandsPassed": sum(item["exitCode"] == 0 for item in manifest["commands"])})
        save()
        print(json.dumps({"status": manifest["status"], "totals": manifest["totals"],
                          "manifest": str(manifest_path), "log": str(log_path)}), flush=True)
        return 1 if failure else 0


if __name__ == "__main__":
    raise SystemExit(main())
