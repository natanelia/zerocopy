#!/usr/bin/env python3
"""Continue core checks without repeating the seven already-passed build/type gates."""
import hashlib
import json
from pathlib import Path
import sys

import run as core

prior = core.ROOT / "attempt-01/combined-validation.json"
record = json.loads(prior.read_text())
assert record["status"] == "failed" and record["failedCommand"] == "full-vitest-bun"
assert len(record["commands"]) == 8
assert all(command["exitCode"] == 0 for command in record["commands"][:7])
inputs = json.loads(core.INPUTS.read_text())
assert core.source_hashes(Path(inputs["combinedDirectory"])) == record["sourceSha256After"]
inputs["priorValidationAttempt"] = {
    "path": str(prior), "sha256": core.digest(prior),
    "passedGatesReused": record["commands"][:7],
    "failure": "Default isolate:false leaked fake dependency fixtures between files; two existing allocation tests exceeded 5 s under parallel suite load",
    "baselineReproduction": str(core.ROOT / "attempt-01/baseline-fixture-leak.json"),
    "baselineReproductionSha256": core.digest(core.ROOT / "attempt-01/baseline-fixture-leak.json"),
    "recovery": "Unchanged suite and runtime with CLI --isolate --testTimeout 15000; do not repeat passed builds/typechecks",
    "recoveryRunnerSha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
}
core.INPUTS.write_text(json.dumps(inputs, indent=2) + "\n")
original_commands = core.commands


def remaining_commands(repository, bun, node):
    steps = original_commands(repository, bun, node)[7:]
    assert steps[0][0] == "full-vitest-bun"
    steps[0] = (steps[0][0], steps[0][1] + ["--isolate", "--testTimeout", "15000"])
    return steps


core.commands = remaining_commands
sys.exit(core.main())
