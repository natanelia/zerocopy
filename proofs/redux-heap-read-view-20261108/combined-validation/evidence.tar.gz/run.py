#!/usr/bin/env python3
"""Run combined correctness gates after both performance studies hand off."""
from __future__ import annotations

import argparse
import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
INPUTS = ROOT / "inputs.json"
LOCK = Path("/tmp/zerocopy-perf-20261108.lock")


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_hashes(repository):
    paths = [path for path in repository.glob("*.ts")]
    paths += [path for path in repository.glob("tsconfig*.json")]
    paths += [repository / "package.json", repository / "scripts/build-browser.ts",
              repository / "scripts/build-wasm.mjs", repository / "scripts/check-package.mjs"]
    for directory in ["proofs/redux-heap-read-view-20261108", "proofs/compaction-vector-copy-20261108"]:
        paths += [path for path in (repository / directory).rglob("*")
                  if path.is_file() and path.suffix in {".mjs", ".py"}]
    paths += list((repository / ".github/workflows").glob("*.yml"))
    return {str(path.relative_to(repository)): digest(path) for path in sorted(set(paths))}


def commands(repository, bun, node):
    heap = "proofs/redux-heap-read-view-20261108"
    compaction = "proofs/compaction-vector-copy-20261108"
    steps = [
        ("build-portable", [bun, "run", "build:browser"]),
        ("build-declarations", [bun, "run", "build:types"]),
        ("typecheck-main", [bun, "run", "typecheck"]),
        ("typecheck-redux", [bun, "run", "typecheck:redux"]),
        ("typecheck-values", [bun, "run", "typecheck:values"]),
        ("typecheck-geometry", [bun, "run", "typecheck:geometry"]),
        ("typecheck-worker", [node, "node_modules/typescript/bin/tsc", "--noEmit", "-p", "tsconfig.worker.json"]),
        ("full-vitest-bun", [bun, "run", "test"]),
        ("focused-vitest-node", [node, "node_modules/vitest/vitest.mjs", "run",
                                 "redux-heap-read-view.test.ts", "compaction-vector-copy.test.ts"]),
        ("node-worker-main", [node, "proofs/node-worker.mjs"]),
        ("node-worker-redux", [node, "proofs/redux-node.mjs"]),
        ("node-worker-typed-json", [node, "proofs/typed-json-worker.mjs"]),
        ("node-worker-heap", [node, f"{heap}/node-workers.mjs", str(repository)]),
        ("node-worker-compaction", [node, f"{compaction}/node-worker.mjs", str(repository)]),
    ]
    for runtime, executable in [("node", node), ("bun", bun)]:
        for mode in ["decode", "view"]:
            steps.append((f"heap-late-import-{runtime}-{mode}",
                          [executable, f"{heap}/late-import.mjs"] + (["--view"] if mode == "view" else [])))
    for mode in ["decode", "view"]:
        steps.append((f"heap-late-import-bun-source-{mode}",
                      [bun, f"{heap}/late-import.mjs", "--source"] + (["--view"] if mode == "view" else [])))
    steps += [
        ("chromium-worker-heap", [node, f"{heap}/browser-check.mjs", str(repository)]),
        ("chromium-worker-compaction", [node, f"{compaction}/browser-check.mjs", str(repository)]),
        ("installed-package", [node, "scripts/check-package.mjs"]),
    ]
    return steps


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--attempt", required=True, help="Fresh evidence directory name; never overwritten")
    parser.add_argument("--both-studies-finished", action="store_true", required=True)
    parser.add_argument("--core-only", action="store_true", help="Run correctness now; append final author evidence/docs after report handoff")
    args = parser.parse_args()
    assert re.fullmatch(r"[a-zA-Z0-9_-]+", args.attempt)
    inputs = json.loads(INPUTS.read_text())
    assert all(inputs.get("handoffs", {}).get(name, {}).get("studiesFinished")
               for name in ["heap", "compaction"]), "Both agents must finish all timing"
    if not args.core_only:
        assert all(inputs["handoffs"][name].get("reportsAndWorkflowFinished")
                   for name in ["heap", "compaction"]), "Wait for final proof-file handoffs"
    repository = Path(inputs["combinedDirectory"])
    evidence = ROOT / args.attempt
    assert not evidence.exists(), "Keep failed attempts intact; choose a fresh directory"
    for candidate in inputs["candidates"].values():
        for name, expected in candidate["runtime"].items():
            assert digest(repository / name) == expected, f"Combined source changed: {name}"
            assert digest(Path(candidate["root"]) / name) == expected, f"Candidate source changed: {name}"
        for name, expected in candidate["testHashes"].items():
            assert digest(repository / name) == expected, f"Combined tests changed: {name}"
    for name, expected in inputs["nativeBuildReuse"]["wasmSha256"].items():
        assert digest(repository / name) == expected, f"Native artifact changed: {name}"
    required = ["proofs/redux-heap-read-view-20261108/node-workers.mjs",
                "proofs/redux-heap-read-view-20261108/late-import.mjs",
                "proofs/redux-heap-read-view-20261108/browser-check.mjs",
                "proofs/compaction-vector-copy-20261108/node-worker.mjs",
                "proofs/compaction-vector-copy-20261108/worker-fixtures.mjs",
                "proofs/compaction-vector-copy-20261108/browser-check.mjs"]
    assert all((repository / name).is_file() for name in required), "Wait for final proof-file handoffs"

    env = os.environ.copy()
    env["PATH"] = "/workspace/scratch/d81d52bea579/bin:" + env.get("PATH", "")
    env["CHROMIUM_EXECUTABLE"] = "/workspace/scratch/102d37e63531/tools/browser/chromium"
    libraries = "/workspace/scratch/102d37e63531/tools/browser/lib"
    env["LD_LIBRARY_PATH"] = libraries + (":" + env["LD_LIBRARY_PATH"] if env.get("LD_LIBRARY_PATH") else "")
    bun, node = shutil.which("bun", path=env["PATH"]), shutil.which("node", path=env["PATH"])
    assert bun and node
    plan = [(name, argv, repository) for name, argv in commands(repository, bun, node)]
    plan.append(("combined-diff-whitespace", ["git", "diff", "--check", inputs["baseline"]], repository))
    if not args.core_only:
        assert inputs.get("additionalGates"), "Wait for authors' final docs and archived-evidence verification commands"
    for extra in ([] if args.core_only else inputs["additionalGates"]):
        assert isinstance(extra["name"], str) and all(isinstance(arg, str) for arg in extra["argv"])
        plan.append((extra["name"], extra["argv"], Path(extra["cwd"])))
    with LOCK.open("a+") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        evidence.mkdir()
        log_path = evidence / "combined-validation.log"
        manifest_path = evidence / "combined-validation.json"
        source_before = source_hashes(repository)
        manifest = {
            **inputs,
            "status": "running", "startedAt": now(), "performanceMeasurements": False,
            "phase": "core" if args.core_only else "complete",
            "handoff": "Both performance agents completed all formal and A/A studies before this runner started",
            "lock": str(LOCK), "runnerSha256": digest(Path(__file__).resolve()),
            "runtime": {"node": subprocess.check_output([node, "--version"], text=True, env=env).strip(),
                        "bun": subprocess.check_output([bun, "--version"], text=True, env=env).strip(),
                        "platform": platform.platform(), "machine": platform.machine()},
            "sourceSha256Before": source_before, "commands": [],
        }

        def save():
            manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")

        save()
        failure = None
        with log_path.open("w") as full_log:
            full_log.write("Combined correctness validation only. No combined speed measurement.\n")
            full_log.write(f"Baseline {inputs['baseline']} with exactly the frozen candidate runtime overlays.\n")
            full_log.flush()
            for index, (name, argv, directory) in enumerate(plan, 1):
                start = time.monotonic()
                record = {"index": index, "name": name, "argv": argv, "cwd": str(directory), "startedAt": now()}
                command_log = evidence / f"{index:02d}-{name}.log"
                full_log.write(f"\n=== {index}/{len(plan)}: {name} ===\n{json.dumps(argv)}\n")
                full_log.flush()
                with command_log.open("w") as destination:
                    process = subprocess.Popen(argv, cwd=directory, env=env, stdout=subprocess.PIPE,
                                               stderr=subprocess.STDOUT, text=True, bufsize=1)
                    assert process.stdout is not None
                    for line in process.stdout:
                        full_log.write(line)
                        destination.write(line)
                        full_log.flush()
                        destination.flush()
                    code = process.wait()
                record.update({"completedAt": now(), "durationSeconds": round(time.monotonic() - start, 6),
                               "exitCode": code, "log": command_log.name, "logSha256": digest(command_log),
                               "logBytes": command_log.stat().st_size})
                manifest["commands"].append(record)
                save()
                print(json.dumps({"step": index, "total": len(plan), "name": name, "exitCode": code,
                                  "durationSeconds": record["durationSeconds"]}), flush=True)
                if code:
                    failure = name
                    break
        manifest["sourceSha256After"] = source_hashes(repository)
        assert manifest["sourceSha256After"] == source_before, "Source/proof changed during validation"
        manifest["builtArtifactSha256"] = {str(path.relative_to(repository)): digest(path)
                                           for path in sorted((repository / "dist").rglob("*")) if path.is_file()}
        manifest["wasmSha256After"] = {name: digest(repository / name)
                                      for name in inputs["nativeBuildReuse"]["wasmSha256"]}
        assert manifest["wasmSha256After"] == inputs["nativeBuildReuse"]["wasmSha256"]
        manifest["completedAt"] = now()
        manifest["status"] = "failed" if failure else "passed"
        manifest["failedCommand"] = failure
        manifest["log"] = {"filename": log_path.name, "sha256": digest(log_path), "bytes": log_path.stat().st_size}
        manifest["totals"] = {"commandsPlanned": len(plan), "commandsCompleted": len(manifest["commands"]),
                              "commandsPassed": sum(command["exitCode"] == 0 for command in manifest["commands"])}
        for name in ["full-vitest-bun", "focused-vitest-node"]:
            command = next((command for command in manifest["commands"] if command["name"] == name), None)
            if command:
                text = re.sub(r"\x1b\[[0-9;]*m", "", (evidence / command["log"]).read_text())
                files, tests = re.search(r"Test Files\s+(\d+)\s+passed", text), re.search(r"Tests\s+(\d+)\s+passed", text)
                if files and tests:
                    manifest["totals"][name] = {"filesPassed": int(files[1]), "testsPassed": int(tests[1])}
        save()
        print(json.dumps({"status": manifest["status"], "totals": manifest["totals"],
                          "manifest": str(manifest_path), "log": str(log_path)}), flush=True)
        return 1 if failure else 0


if __name__ == "__main__":
    sys.exit(main())
