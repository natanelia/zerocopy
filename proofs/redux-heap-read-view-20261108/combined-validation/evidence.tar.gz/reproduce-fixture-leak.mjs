import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
const root = process.argv[2];
const { SharedMap, SharedSet, getWorkerData, resetMap } = await import(pathToFileURL(`${root}/shared.ts`).href);
const { arenaOf } = await import(pathToFileURL(`${root}/arena.ts`).href);
resetMap();
const clean = new SharedSet().add(1);
assert.doesNotThrow(() => getWorkerData({ clean }, { copy: true }));
const lanes = new SharedMap('number').set('n', 1), owner = arenaOf(lanes);
// Same fake dependency shape as the unchanged worker-records.test.ts fixture.
const fake = { id: 'traversal-fixture', used: owner.used, memory: owner.memory, dependencies: new Map() };
owner.dependencies.set(fake.id, fake);
const inherited = new SharedSet().add(2);
assert.equal(arenaOf(inherited), owner);
let error;
try { getWorkerData({ inherited }, { copy: true }); } catch (caught) { error = caught; }
assert(error instanceof TypeError && error.message.includes('arena.copy'));
resetMap();
assert.doesNotThrow(() => getWorkerData({ cleanAgain: new SharedSet().add(3) }, { copy: true }));
console.log(JSON.stringify({ root, cleanCopy: 'passed', fakeDependencyCopy: error.message, resetCopy: 'passed' }));
