"""Verify this retained evidence using only Python's standard library.

Usage: python3 verify.py [evidence-directory]
No subject or original analysis code is imported or executed.
"""
from collections import Counter
from datetime import datetime
from pathlib import Path
import hashlib
import json
import math
import re
import statistics as st
import sys


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def compare(actual, expected, where):
    if isinstance(expected, bool) or expected is None or isinstance(expected, str):
        require(actual == expected, where)
    elif isinstance(expected, (int, float)):
        require(isinstance(actual, (int, float)) and
                math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-12), where)
    elif isinstance(expected, list):
        require(isinstance(actual, list) and len(actual) == len(expected), where)
        for i, (a, e) in enumerate(zip(actual, expected)):
            compare(a, e, f'{where}[{i}]')
    else:
        require(isinstance(actual, dict) and actual.keys() == expected.keys(), where)
        for key in expected:
            compare(actual[key], expected[key], where + '.' + key)


def main():
    root = Path(sys.argv[1]) if len(sys.argv) == 2 else Path(__file__).resolve().parent
    require(len(sys.argv) <= 2, 'Expected at most one directory argument')
    load = lambda name: json.loads((root / name).read_text())
    manifest = load('MANIFEST.json')
    entries = manifest['files']
    names = [entry['file'] for entry in entries]
    require(len(names) == len(set(names)), 'Duplicate whitelist entry')
    expected_files = set(names) | {'MANIFEST.json'}
    actual_files = {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
    require(actual_files == expected_files, 'Missing or unexpected files')
    require(not any(p.is_symlink() for p in root.rglob('*')), 'Symlink in export')
    for name in expected_files:
        require(not Path(name).is_absolute() and '..' not in Path(name).parts, 'Unsafe filename')
        text = (root / name).read_bytes().decode('utf-8')
        require(not re.search(r'(?<![\w])(?:/[A-Za-z][\w.-]*){2,}', text), 'Absolute path in ' + name)
        require(not re.search(r'[A-Za-z]:\\[^\s"<>]+', text), 'Drive path in ' + name)
    by_file = {e['file']: e for e in entries}
    for name, entry in by_file.items():
        data = (root / name).read_bytes()
        require(len(data) == entry['bytes'] and digest(data) == entry['sha256'], 'Hash mismatch: ' + name)
    protocol, cases = load('PROTOCOL.json'), load('CASES.json')
    summary, provenance = load('SCIENTIFIC-SUMMARY.json'), load('PROVENANCE.json')
    require(provenance['baselineMainCommit'] == '8a9075aa530f4cc65c577ed665389ba440d5d156', 'Baseline identity')
    expected_raw = {f'results/calibration-{rt}-{c["name"]}-{arm}.json'
                    for rt in protocol['engineOrder'] for c in cases for arm in ['baseline', 'candidate']}
    expected_raw |= {f'results/sample-{slot}-{rt}-{c["name"]}-{arm}.json'
                     for slot, arm in enumerate(protocol['armOrder'])
                     for rt in protocol['engineOrder'] for c in cases}
    require(len(expected_raw) == 80 and {n for n in names if n.startswith('results/')} == expected_raw,
            'Raw result coverage')
    results, counts = {}, Counter()
    source_digests = set()
    for name in sorted(expected_raw):
        data = (root / name).read_bytes()
        require(by_file[name]['originalSHA256'] == digest(data), 'Original result digest: ' + name)
        result = json.loads(data)
        require(result['passed'] and result['disposed'] and result['event'] == 'complete', 'Incomplete result')
        require(result['protocol'] == protocol, 'Protocol mismatch')
        source_digests.add(result['inputPinsSHA256'])
        item = next(c for c in cases if c['name'] == result['caseName'])
        keys = [f'lane{i:03d}' for i in range(item['names'])]
        fixture = dict(names=keys, initialValues=[0, 1], changedName=keys[-1] if keys else None,
                       publishesPerCycle=item['publishesPerCycle'], flushesPerCycle=item['flushesPerCycle'],
                       operationsPerCycle=32, setupVersion=int(item['name'] in ['unchanged-128', 'reverted-one']),
                       changedThenReverted=item['name'] == 'reverted-one')
        require(result['fixture'] == fixture, 'Fixture mismatch')
        require(result['fixtureSHA256'] == digest(json.dumps(fixture, separators=(',', ':')).encode()), 'Fixture digest')
        require(result['environment'] == provenance['environmentByRuntime'][result['runtime']], 'Environment mismatch')
        key = (result['runtime'], result['caseName'], result['arm'], result['slot'])
        require(key not in results, 'Repeated process identity')
        results[key] = result
        version = fixture['setupVersion']
        for row in result['batches']:
            counts[row['phase']] += 1
            require(row['event'] == 'batch', 'Batch event')
            for field in ['mode', 'runtime', 'arm', 'slot', 'caseName', 'fixtureSHA256']:
                require(row[field] == result[field], 'Batch identity mismatch')
            cycles = row['cycles']
            require(type(cycles) is int and 1 <= cycles <= item['maxCycles'], 'Cycle count')
            operations, publications = cycles * 32, cycles * item['publishesPerCycle']
            require(row['operations'] == operations and row['publications'] == publications and
                    row['explicitFlushes'] == cycles * item['flushesPerCycle'], 'Operation counts')
            checksum = ((publications * version + publications * (publications + 1) // 2) *
                        (32 if item['name'] == 'mixed-128' else 1) if publications else operations * version) & 0xffffffff
            require(row['versionBefore'] == version, 'Version before')
            version += publications
            require(row['versionAfter'] == version and row['checksum'] == row['expectedChecksum'] == checksum,
                    'Version/checksum mismatch')
            require(0 < row['ns'] <= protocol['batchCeilingNs'], 'Batch duration cap')
            require(row['nsPerOperation'] == row['ns'] / operations and row['nsPerCycle'] == row['ns'] / cycles,
                    'Duration normalization')
            require(row['belowFloor'] == (row['ns'] < protocol['floorNs']) and not row['overTimeCap'] and
                    not row['overRSSCap'] and max(row['beforeRSS'], row['afterRSS']) <= protocol['rssMiBCap'] * 1048576,
                    'Batch floor/RSS metadata')
        require(result['operationsPerBatch'] == result['cycles'] * 32, 'Result operation count')
        batches = result['batches']
        if result['mode'] == 'calibrate':
            require(result['slot'] == -1 and result['calibrationSHA256'] is None, 'Calibration identity')
            n = protocol['calibrationSeedWarmups']
            require([(b['phase'], b['index'], b['cycles']) for b in batches[:n]] ==
                    [('seed-warmup', i, protocol['seedCycles']) for i in range(n)], 'Seed warmups')
            pilots, cycles = batches[n:], protocol['seedCycles']
            require(1 <= len(pilots) <= protocol['maxPilots'], 'Pilot count')
            for i, pilot in enumerate(pilots):
                require((pilot['phase'], pilot['index'], pilot['cycles']) == ('pilot', i, cycles), 'Pilot progression')
                if i < len(pilots) - 1:
                    require(pilot['ns'] < protocol['targetNs'] and cycles < item['maxCycles'], 'Pilot stop condition')
                    growth = min(protocol['growthMax'], max(protocol['growthMin'],
                                 protocol['growthHeadroom'] * protocol['targetNs'] / pilot['ns']))
                    cycles = min(item['maxCycles'], math.ceil(cycles * growth))
            require(result['cycles'] == cycles and pilots[-1]['ns'] >= protocol['targetNs'] and
                    not result['capped'] and result['capReason'] is None, 'Calibration target')
        else:
            require(result['mode'] == 'measure' and protocol['armOrder'][result['slot']] == result['arm'], 'Arm schedule')
            expected_phases = [('warmup', i) for i in range(protocol['warmups'])] + [('measure', i) for i in range(protocol['samples'])]
            require([(b['phase'], b['index']) for b in batches] == expected_phases, 'Measurement batch schedule')
            require(all(b['cycles'] == result['cycles'] for b in batches), 'Fixed measurement count')
    require(len(source_digests) == 1, 'Inconsistent retained input digest')
    require(counts == Counter({'seed-warmup': 32, 'pilot': 58, 'warmup': 128, 'measure': 192}), 'Raw batch totals')
    receipt_data = load('RECEIPTS.json')
    receipts = receipt_data['records']
    require(len(receipts) == 81, 'Receipt count')
    flattened, seen, prior_end = [], set(), None
    for i, rec in enumerate(receipts):
        require(rec['commandIndex'] == i and int(rec['commandId'][:3]) == i, 'Receipt order')
        r = rec['receipt']
        require(r['state'] == 'passed' and r['spawned'] and r['returncode'] == rec['supervisorReturncode'] == 0 and
                r['limit'] is r['error'] is r['signal'] is None, 'Process exit')
        require(r['cleanup'] == dict(remainingBeforeCleanup=[], remainingAfterCleanup=[], confirmedEmpty=True,
                                    signals=[], errors=[]), 'Process cleanup')
        require(r['cwd'] == '<study-directory>' and r['elapsedSeconds'] <= r['secondsCap'] and
                r['peakPolledRSS'] <= r['rssMiBCap'] * 1048576, 'Process budget')
        for field in ['originalReceiptSHA256', 'originalStdoutSHA256', 'originalSupervisorStdoutSHA256']:
            require(re.fullmatch('[0-9a-f]{64}', rec[field]), 'Original receipt hash')
        start, end = datetime.fromisoformat(r['startedUtc']), datetime.fromisoformat(r['endedUtc'])
        require(start <= end and (prior_end is None or start >= prior_end), 'Overlapping receipt times')
        prior_end = end
        if i == 80:
            require(rec['phase'] == 'analysis' and rec['originalSummarySHA256'] == summary['sourceSummarySHA256'], 'Analysis receipt')
            continue
        name = rec['resultFile']
        require(name in expected_raw and name not in seen, 'Receipt result coverage')
        seen.add(name)
        require(rec['originalResultSHA256'] == by_file[name]['originalSHA256'], 'Receipt result digest')
        result = load(name)
        require(rec['phase'] == result['mode'] and rec['endpoint'] == result['caseName'] and
                all(rec[k] == result[k] for k in ['runtime', 'arm', 'slot']), 'Receipt result identity')
        require(r['secondsCap'] == protocol['processSecondsCap'] and r['rssMiBCap'] == protocol['rssMiBCap'], 'Subject caps')
        flattened.extend(dict(resultFile=name, originalResultSHA256=rec['originalResultSHA256'], batch=b) for b in result['batches'])
    require(seen == expected_raw, 'Unrepresented raw result')
    require(flattened == [json.loads(line) for line in (root / 'BATCHES.jsonl').read_text().splitlines()], 'Flattened 410 rows')
    whole = receipt_data['wholeRun']
    require(whole['state'] == 'passed' and whole['error'] is whole['signal'] is None and
            whole['elapsedSeconds'] <= whole['wholeSecondsCap'] == protocol['wholeSecondsCap'], 'Whole-run budget')
    require(len(summary['endpoints']) == 8, 'Endpoint count')
    recomputed = []
    for item in cases:
        for runtime in protocol['engineOrder']:
            processes = [results[(runtime, item['name'], arm, slot)] for slot, arm in enumerate(protocol['armOrder'])]
            calibrations = {arm: results[(runtime, item['name'], arm, -1)] for arm in ['baseline', 'candidate']}
            for process in processes:
                cal = calibrations[process['arm']]
                cal_file = f'results/calibration-{runtime}-{item["name"]}-{process["arm"]}.json'
                require(process['calibrationSHA256'] == by_file[cal_file]['originalSHA256'] and
                        all(process[k] == cal[k] for k in ['cycles', 'capped', 'capReason', 'environment', 'fixture']), 'Calibration reuse')
            times = [st.median(b['ns'] / b['operations'] for b in p['batches'] if b['phase'] == 'measure') for p in processes]
            ratios = [times[c] / times[b] for b, c in protocol['pairIndexesBaselineCandidate']]
            saved = [times[b] - times[c] for b, c in protocol['pairIndexesBaselineCandidate']]
            log_ratios = [math.log(r) for r in ratios]
            center = st.mean(log_ratios)
            half = protocol['logRatioTCriticalDf3'] * st.stdev(log_ratios) / math.sqrt(len(ratios))
            interval = [math.exp(center - half), math.exp(center + half)]
            aa, bb = [times[3] / times[0], times[6] / times[5]], [times[2] / times[1], times[7] / times[4]]
            baseline, candidate = [times[i] for i in [0, 3, 5, 6]], [times[i] for i in [1, 2, 4, 7]]
            a_range, b_range = max(baseline) / min(baseline) - 1, max(candidate) / min(candidate) - 1
            spreads = [max(b['nsPerOperation'] for b in p['batches'][2:]) / min(b['nsPerOperation'] for b in p['batches'][2:]) - 1 for p in processes]
            short_m = any(b['belowFloor'] for p in processes for b in p['batches'][2:])
            short_w = any(b['belowFloor'] for p in processes for b in p['batches'][:2])
            capped = any(c['capped'] for c in calibrations.values())
            noisy = max([abs(x - 1) for x in aa + bb] + [a_range, b_range]) > protocol['repeatedArmNoiseFraction'] or max(spreads) > protocol['withinProcessNoiseFraction']
            adverse = [i for i, r in enumerate(ratios) if r >= protocol['adverseRatio']]
            gain = max(ratios) < 1 and interval[1] <= protocol['gainUpperRatio'] and st.median(saved) >= protocol['minimumSavedNsPerOperation'] and 1 - st.median(ratios) > max(abs(x - 1) for x in aa) and not (short_m or short_w or capped)
            loss = interval[0] > protocol['adverseRatio']
            unresolved = bool(adverse) or noisy or short_m or short_w or capped or interval[1] > protocol['adverseRatio']
            endpoint = dict(name=item['name'], role=item['role'], runtime=runtime, pairedGainThresholdMet=gain,
                            materialLossCriterionMet=loss, unresolvedUnderScreenRules=unresolved, independentPairCount=4,
                            baselineNsPerOperation=baseline, candidateNsPerOperation=candidate, allProcessNsPerOperation=times,
                            allProcessNsPerCycle=[t * 32 for t in times], pairedCandidateOverBaseline=ratios,
                            pairedMedianRatio=st.median(ratios), geometricMeanRatio=math.exp(center),
                            descriptive95LogRatioInterval=interval, pairedSavedNsPerOperation=saved, medianSavedNsPerOperation=st.median(saved),
                            aaRatios=aa, bbRatios=bb, baselineRangeFraction=a_range, candidateRangeFraction=b_range,
                            withinProcessRanges=spreads, noisy=noisy, shortMeasuredBatch=short_m, shortWarmBatch=short_w,
                            calibrationCapped=capped, adversePairIndexesAtTwoPercent=adverse,
                            calibratedCyclesByArm={a: c['cycles'] for a, c in calibrations.items()},
                            calibratedOperationsByArm={a: c['cycles'] * 32 for a, c in calibrations.items()},
                            absoluteBatchNsByProcess=[[b['ns'] for b in p['batches']] for p in processes])
            recomputed.append(endpoint)
    compare(summary['endpoints'], recomputed, 'endpoints')
    compare({k: summary[k] for k in ['rawBatchCount', 'measuredBatchCount', 'measurementProcessCount', 'calibrationProcessCount']},
            dict(rawBatchCount=410, measuredBatchCount=192, measurementProcessCount=64, calibrationProcessCount=16), 'counts')
    require(all(e['noisy'] for e in recomputed), 'Eight noisy cells')
    require(sum(len(e['adversePairIndexesAtTwoPercent']) for e in recomputed) == 8, 'Eight adverse pairs')
    require(summary['blockingCells'] == [] and summary['unresolvedCells'] == [dict(runtime=e['runtime'], name=e['name']) for e in recomputed], 'Cell flags')
    require(summary['primaryThresholdMetInBothEngines'] and all(e['pairedGainThresholdMet'] for e in recomputed if e['role'] == 'primary') and
            summary['status'] == 'promising-for-independent-validation', 'Primary conclusion')
    print(json.dumps(dict(passed=True, hashedFiles=len(entries), originalResults=80, rawBatches=sum(counts.values()),
                          measuredBatches=counts['measure'], receipts=len(receipts), endpoints=len(recomputed),
                          noisyCells=8, adverseControlPairs=8), sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, KeyError, TypeError, OSError, json.JSONDecodeError) as error:
        print('Verification failed: ' + str(error), file=sys.stderr)
        sys.exit(1)
