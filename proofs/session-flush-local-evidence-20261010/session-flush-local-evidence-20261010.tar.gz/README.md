# Session-flush latency: retained scientific evidence

The primary workload is one changed publication over 128 names followed by 31 unchanged explicit flushes. Across four fixed baseline/candidate process pairs, the median paired reduction in normalized latency was **59.7% on Node** and **38.6% on Bun**. This is the average over that 32-operation mix, not a reduction of that size for changed publication alone.

Both primary cells meet the prospective gain rule, but **all eight endpoint/runtime cells are noisy and unresolved**. The controls contain **eight adverse pairs** at a candidate/baseline ratio of at least 1.02. The result is a promising narrow observation, not general performance, equivalence, no-regression, or completed current-source CI evidence.

## Workload and method

Recorded on 10 October 2026, 07:15–07:16 UTC.

The candidate adds a state-identity check before the existing structural comparison in session commit. The recorded baseline is main commit `8a9075aa530f4cc65c577ed665389ba440d5d156`. Source, runtime executable, and bundle identities are in `PROVENANCE.json`; source and subject binaries are not redistributed here.

The fixed case set includes:

- `mixed-128` (primary): 128 names, one changed publication and 31 flushes per cycle.
- `unchanged-128` (secondary mechanism): 128 names, 32 unchanged flushes per cycle. This pure no-op loop cannot substitute for the primary endpoint.
- `changed-single` (changed-path control): a single map, 32 changed publications per cycle.
- `reverted-one` (distinct-but-equal control): one named value, reverted through public updates, then 32 flushes per cycle.

Inputs and fixtures were prebuilt and retained; sessions were unconnected. Changed publication includes ordinary capture/serialization work. Timing excludes fixture construction and surrounding validation. Version transitions, exact uint32 checksums, and post-batch state checks consumed results and checked behavior, without proving that a runtime cannot simplify a loop.

Each runtime/case/arm received its own prospective calibration: two seed warmups, up to seven growing pilots, a 100 ms target, a 50 ms batch floor, and fixed count ceilings. The selected count was then reused in all four measurement processes for that arm. All 16 calibrations reached target and none was capped. The Node unchanged candidate reached its count ceiling on a successful pilot; this is not a capped result.

For each case, the eight process slots use baseline/candidate/candidate/baseline/candidate/baseline/baseline/candidate. Fixed pairs are (0,1), (3,2), (5,4), and (6,7), with baseline first in each pair. Each process has two warmups and three measured batches. A process estimate is the median of its three normalized measured batch durations. The independent sample count is four pairs per cell, not the number of batches. Runtime order is Node then Bun and case order follows `CASES.json`. The schedule was fixed; all results are included.

The original `PROTOCOL.json` and `CASES.json` are unchanged. The protocol's historical `prepared-not-executed` label describes its preparation state, not the completed results. All thresholds and calibration parameters remain inspectable in that file.

## All endpoints

Arm times are medians of four process estimates in ns/public operation. Paired ratios use the four fixed pairs and need not equal the ratio of arm medians. Intervals are descriptive 95% log-ratio t intervals with 3 degrees of freedom.

| Endpoint / runtime | Baseline → candidate ns/op | Median paired C/B | Descriptive interval | Adverse pairs |
|---|---:|---:|---:|---:|
| mixed-128 / Node | 12,279.073 → 4,946.915 | 0.403026 | 0.332773–0.494103 | 0/4 |
| mixed-128 / Bun | 3,070.084 → 1,949.159 | 0.613857 | 0.564818–0.664268 | 0/4 |
| unchanged-128 / Node | 6,923.807 → 2.572 | 0.000375344 | 0.000321157–0.000436398 | 0/4 |
| unchanged-128 / Bun | 1,377.710 → 4.191 | 0.003105677 | 0.002828899–0.003428485 | 0/4 |
| changed-single / Node | 2,235.763 → 2,190.161 | 0.983115 | 0.872541–1.086217 | 2/4 |
| changed-single / Bun | 1,295.465 → 1,347.565 | 1.041931 | 0.889766–1.235478 | 2/4 |
| reverted-one / Node | 181.662 → 170.660 | 0.975054 | 0.846050–1.170293 | 1/4 |
| reverted-one / Bun | 31.036 → 32.343 | 1.042221 | 0.984339–1.080220 | 3/4 |

Primary paired median savings are 7,332.157 ns/op on Node and 1,185.058 ns/op on Bun. The fixed gain rule requires every pair below 1, an upper interval bound at most 0.95, median savings of at least 10 ns/op, relative paired median gain greater than the largest repeated-baseline deviation, and no short or capped batches. Both primary cells satisfy this rule. The four controls remain inconclusive: all upper interval bounds exceed 1.02. No lower interval bound exceeds 1.02; absence of that material-loss signal does not establish equivalence.

## Calibration counts and limits

These cycles per batch were selected separately per arm before measurement. Each cycle contains 32 public operations.

| Endpoint / runtime | Baseline cycles | Candidate cycles |
|---|---:|---:|
| mixed-128 / Node | 266 | 1,024 |
| mixed-128 / Bun | 1,116 | 1,808 |
| unchanged-128 / Node | 490 | 4,194,304 |
| unchanged-128 / Bun | 3,209 | 943,602 |
| changed-single / Node | 1,470 | 1,498 |
| changed-single / Bun | 4,210 | 2,335 |
| reverted-one / Node | 23,031 | 23,285 |
| reverted-one / Bun | 174,334 | 163,966 |

Different counts mean different garbage-collection and JIT/tiering exposure. Dividing by operations does not remove that limitation. There were no separate GC or tiering measurements. Extremely small secondary candidate times may reflect extensive JIT simplification. Four pairs have limited resolution, and the descriptive intervals are vulnerable to shared-host drift and serial dependence. Every cell exceeds at least one prospective noise rule: 5% repeated-arm variation or 10% within-process variation. No samples were dropped to reduce that noise.

This Linux x64 run used Node v22.23.3 and Bun 1.4.2 on an AMD EPYC 9V74 host reporting nine CPUs. It does not measure listeners, endpoints, real worker delivery, startup, browsers, ARM64, or general application workloads. Compatibility outside ordinary intrinsics and unmodified private properties is not established by this study.

## Included evidence and verification

`results/` contains exactly 80 original JSON files: 16 calibrations and 64 measurement-process results. Their bytes are unchanged. `BATCHES.jsonl` provides all 410 raw rows in command order: 32 calibration seed warmups, 58 pilots, 128 process warmups, and 192 measured batches. It retains every adverse sample. `SCIENTIFIC-SUMMARY.json` is explicitly derived: all original scientific values are unchanged; two prose fields were replaced with neutral scientific interpretation. `TRANSFORMATIONS.json` records every transformation.

`RECEIPTS.json` contains all 81 sanitized process receipts, including the final analysis process. Technical timing, cap, exit, RSS and cleanup data are unchanged; absolute working-directory and command paths are replaced, with original byte hashes retained. All processes exited zero and reported their original process groups empty without cleanup signals or errors. Recorded whole-run duration was 99.299 s, maximum completed batch 373.768 ms, maximum subject process 1.869 s, and maximum polled RSS 86,634,496 bytes. These are budget-compliance observations, not memory-saving or controller-performance estimates. Polling can miss brief peaks; original-group cleanup cannot establish the absence of escaped groups or unrelated host activity.

Run `python3 verify.py` from this directory, or pass the directory as the sole argument. The small standalone checker uses only the Python standard library. It hashes the explicit manifest whitelist, rejects extra files, screens exported text for absolute paths, reconstructs all 410 rows and calibrations, reconciles original result digests, validates technical receipts, and independently recomputes every endpoint, noise flag and adverse pair. It neither imports the subject nor runs the benchmark. A manifest demonstrates retained-file integrity, not a third-party signature. No new timing, subject imports, builds, tests, or CI runs were performed to produce this export.
